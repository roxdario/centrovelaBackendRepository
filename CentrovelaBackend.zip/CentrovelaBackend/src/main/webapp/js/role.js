function closeDetailDialog() {

	$('#detailModal').hide();
	
}

function getRoleFromServer(id) {
	
	console.log("getRoleFromServer: "+id);

	var url =	roleApi + id;
	console.log(url);
	$.ajax({
		type : 'GET',
		url : url,
		dataType : 'json',
		success : function(data, textStatus, jQxhr) {
			console.log("OK"+data);
			$('#idRole').val(data.id)
			$('#label').val(data.label);
			console.log(data.label);
			$('#description').val(data.description);
			$('#level').val(data.level);
		},
		failure : function(data, textStatus, jQxhr) {
			console.log("KO" + data);
		}
	});
}

function createTable(currentList) {
	
	console.log("Invocato refreshTable()");
	var startTable = "<table> " +
					"<tr> " +
						"<th>"+label+"</th>"+
						"<th>"+description+"</th>"+
						"<th>"+level+"</th>"+
						"<th></th>"+
						"<th></th>"+
					"</tr>" ;
	
	var bodyTable = "";
	
	for(var i=0 ;i<currentList.length ; i++) {
		
		var tmp ="<tr>" +
						"<td align='right' bgcolor='#ffffff'>"+currentList[i].label+"</td>"+
						"<td align='right' bgcolor='#ffffff'>"+currentList[i].description+"</td>"+
						"<td align='right' bgcolor='#ffffff'>"+currentList[i].level+"</td>"+
						"<td>" +
				  			"<input type='button' value='Delete' onclick='deleteById("+currentList[i].id+");'>"+
				  	   "</td>"	+
				  		"<td>"+
				  			"<input type='button' id='myBtn' value='Modifica' onclick='openDetailDialogUpdate("+currentList[i].id+");'>"+
				  		"</td>" +
				  "<tr>";
		
		bodyTable += tmp;
	}

	var endTable ="</table>";
	$('#tableList').html(startTable + bodyTable + endTable);
}

function refreshTable()  {
	
	console.log("refreshTable() chiamato");
	$.ajax({
		type : 'GET',
		url : roleApi,
		dataType : 'json',
		beforeSend: function (xhr) {
//			xhr.setRequestHeader ("Access-Control-Allow-Origin", "*"));
			
		},
//		beforeSend: function (xhr) {
//		    xhr.setRequestHeader ("Authorization", "Basic " + btoa("user" + ":" + "password"));
//		},
		
//		xhrFields: {
//	        withCredentials: true
//	    },
	    crossDomain: true,
		success : function(data, textStatus, jQxhr) {
			console.log("OK"+data);
			createTable(data);
			
		},
		failure : function(data, textStatus, jQxhr) {
			console.log("KO" + data);
		}
	});
}	

function openDetailDialogUpdate(id) {

	console.log("id: "+id);
	$('#editButton').show();
	$('#updateLabel').show();
	$('#insertButton').hide();
	$('#insertLabel').hide();

	$('#labelError').hide();
	$('#label').css("background-color", "white");
	$('#levelError').hide();
	$('#level').css("background-color", "white");
	
	getRoleFromServer(id);
	
	$('#detailModal').show();
}

function update() {

	var data = {	
//					"id":  $('#idRole').val(),
					"label": $('#label').val(), 
					"description": $('#description').val(),
					"level": $('#level').val()
				};

	if((validateForm(data.label,data.description,data.level))) {

		$.ajax({
			type: "POST",
			url: roleApi,
			data: data,
			dataType: 'json',
			success: function(returnMsg)
			{
				console.log("OK"+returnMsg);

				if(returnMsg == true) {
					refreshTable();
				}
				closeDetailDialog();
			},
			error: function()
			{
				console.log("KO");
				closeDetailDialog();
			}
		});
	}
}


function deleteById(id) {

	console.log("deleteById Id: "+id);
//	var dataDelete = {"id":id};
	
	$.ajax({
		type: "POST",
		url: roleApi + id,
		dataType: 'json',
		success: function(returnMsg)
		{
			console.log("OK"+returnMsg);
			
			if(returnMsg == true) {
				refreshTable();
			}
		},
		error: function()
		{
			console.log("KO");
		}
	});
}

function openDetailDialogInsert() {

	$('#editButton').hide();
	$('#updateLabel').hide();
	$('#insertButton').show();
	$('#insertLabel').show();

	$('#labelError').hide();
	$('#label').css("background-color", "white");
	$('#levelError').hide();
	$('#level').css("background-color", "white");
	
	$('#label').val("");
	$('#description').val("");
	$('#level').val("");
	
	$('#detailModal').show();
}

function insert() {

	var data = {	"label": $('#label').val(), 
					"description": $('#description').val(),
					"level": $('#level').val()
			   };

	if((validateForm(data.label,data.description,data.level))) {

		$.ajax({
			type: "POST",
			url: roleApi,
			data: data,
			dataType: 'json',
			contentType: 'application/json',
			success: function(returnMsg)
			{
				console.log("OK"+returnMsg);
				
				if(returnMsg == true) {
					refreshTable();
				}
				$('#detailModal').hide();
			},
			error: function()
			{
				console.log("KO");
				$('#detailModal').hide();
			}
		});
	}
}

function validateForm(label,description,level) {
	
	console.log("validateForm");
	console.log(label);
	console.log(description);
	console.log(level);

	if (level > 0) {
		if (label.length < 2) {
			$('#labelError').show();
			$('#label').css("background-color", "red");
			return false;
		} 
	} else {
		$('#levelError').show();
		$('#level').css("background-color", "red");
		return false;
	}

	return true;
}