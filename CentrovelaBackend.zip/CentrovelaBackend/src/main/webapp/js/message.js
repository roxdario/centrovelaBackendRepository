/**
 * 
 */
		var modal = document.getElementById('detailModal');
		

		window.onclick = function(event) {
		    if (event.target == modal) {
		        modal.style.display = "none";
		    }
		}
		
		function closeDetailDialog() {

			 document.getElementById('detailModal').style.display = "none"; 
		}
		function getMessagesFromServer(id) {
			console.log("getEntityFromServer: "+id);
			var xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
			    if (this.readyState == 4 && this.status == 200) {
			    	console.log(this.responseText);
			    	currentObj=JSON.parse(this.responseText);
			    }
			  };
			  xhttp.open("GET", getAction, true);
			  xhttp.send();
		}
		
		function createTable(){
			console.log("invocato refresh Table");
			var startTable="<table><th>message.table.userid</th><th>message.table.textmessage</th> <th>message.table.attachmentfilename</th><th></th><th></th></tr>" ;
		    var bodyTable="";
			for (var i=0;i<currentList.length;i++){
				var tmp= "<tr><td align='right' bgcolor='#ffffff'>"+currentList[i].userId+"</td>"+
				"<td align='right' bgcolor='#ffffff'>"+currentList[i].textMessage+"</td>"+
				"<td align='right' bgcolor='#ffffff'>"+currentList[i].attachmentFileName+"</td>"+
				"<td><form id='messageFormDelete"+currentList[i].id+"' action='" + deleteAction+ "' method='POST'>"+
				 "<input type='hidden' name='id' id='idMessageDelete' value='"+currentList[i].id+"'>"+
				"<input type='button' value='Delete' onclick='deleteById("+currentList[i].id+");'>"+
				"</form></td><td><input type='button' id='myBtn' value='Modifica' onclick='openDetailDialogUpdate("+currentList[i].id+");'/>"+
				"</td><tr>";
				bodyTable+=tmp;
			}
			
		    var endTable="</table>";
			document.getElementById("tableList").innerHTML = startTable+bodyTable+endTable;

			
		}
		
		function refreshTable() {
			console.log("getAllEntities chiamato");
			var xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
			    if (this.readyState == 4 && this.status == 200) {
			    	console.log(this.responseText);
			    	currentList=JSON.parse(this.responseText);
			    	createTable();
			    	
			    }
			  };
			  xhttp.open("GET", getListAction, true);
			  xhttp.send();
		}

		function openDetailDialogUpdate(id) {

			console.log("id: "+id);
			document.getElementById("editButton").style.display = 'block';
			document.getElementById("updateLabel").style.display = 'block';
			document.getElementById("insertButton").style.display = 'none';
			document.getElementById("insertLabel").style.display = 'none';
			
			
			getMessagefromServer(id);
			if(currentObj != null){
				
			
			
			
			
		    document.getElementById("idMessage").value = currentObj.id;

			document.getElementById("userid").value = currentObj.userid;
			document.getElementById("textmessage").value = currentObj.textmessage;
			document.getElementById("attachmentfilename").value = currentObj.attachmentfilename;
			}
			document.getElementById("detailModal").style.display = 'block';

			
		}
		
		function update() {
			
			var id = document.getElementById("idMessage").value;
			var userid = document.getElementById("userid").value;
			var textmessage = document.getElementById("textmessage").value;
			var attachmentfilename = document.getElementById("attachmentfilename").value;
			
			console.log("id: "+id+" userid: "+userid+" textmessage: "+textmessage+" attachmentfilename: "+attachmentfilename);
			
			document.getElementById("messageForm").action = updateAction;
			document.getElementById("messageForm").submit();
		}
		
		
		function deleteById(id) {
	
			console.log("deleteById Id: "+id);
			
//			document.getElementById("idMessageDelete").value = id;
//			var id1 = document.getElementById("idMessageDelete").value;
//			
		   document.getElementById("messageFormDelete"+id).submit();
		}
		
		function openDetailDialogInsert() {
			
			document.getElementById("editButton").style.display = 'none';
			document.getElementById("updateLabel").style.display = 'none';
			document.getElementById("insertButton").style.display = 'block';
			document.getElementById("insertLabel").style.display = 'block';
			document.getElementById("detailModal").style.display = 'block';
			document.getElementById("userid").value = "";
			document.getElementById("textmessage").value = "";
			document.getElementById("attachmentfilename").value = "";
		}
		
		function insert() {
			
			var userid = document.getElementById("userid").value;
			var textmessage = document.getElementById("textmessage").value;
			var attachmentfilename = document.getElementById("attachmentfilename").value;
			
// 			if(!(validateForm(userid,textmessage,attachmentfilename))) {
//				
// 				return
// 			}
			
			document.getElementById("messageForm").action = insertAction;
			document.getElementById("messageForm").submit();
		
		}
		
		function validateForm(userid,textmessage,attachmentfilename) {
			console.log("validateForm");
			console.log(userid);
			console.log(textmessage);
			console.log(attachmentfilename);
			
			if (userid > 0) {
				if (label.length < 2) {
					document.getElementById("labelError").style.display = 'block';
					document.getElementById("label").style.backgroundColor = 'red';
					return false;
				} 
			} else {
				document.getElementById("levelError").style.display = 'block';
				document.getElementById("level").style.backgroundColor = 'red';
				return false;
			}
			
			return true;
		}