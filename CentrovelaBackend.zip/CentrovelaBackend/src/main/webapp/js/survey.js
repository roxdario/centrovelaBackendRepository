
function validateInsertForm() {
	return true ;
}

function prepareDataToInsert(){
	var data = {	"label": $('#label').val(),
					"description": $('#description').val()
				};
	return data ;
}





function closeDetailDialog() {

	$('#detailModal').hide();
	
}

function getSurveyFromServer(id) {
	
	console.log("getSurveyFromServer: "+id);

	var url = resourceApi + id;
	console.log(url);
	$.ajax({
		type : 'GET',
		url : url,
		dataType : 'json',
		success : function(data, textStatus, jQxhr) {
			console.log("OK"+data);
			$('#idSurvey').val(data.id)
			$('#label').val(data.label);
			console.log(data.label);
			$('#description').val(data.description);
		},
		failure : function(data, textStatus, jQxhr) {
			console.log("KO" + data);
		}
	});
}

function createTable(currentList) {
	
	console.log("Invocato createTable()");
	var startTable = "<table> " +
					"<tr> " +
						"<th>"+label+"</th>"+
						"<th>"+description+"</th>"+
						"<th></th>"+
						"<th></th>"+
					"</tr>" ;
	
	var bodyTable = "";
	
	for(var i=0 ;i<currentList.length ; i++) {
		
		var tmp ="<tr>" +
						"<td align='right' bgcolor='#ffffff'>"+currentList[i].label+"</td>"+
						"<td align='right' bgcolor='#ffffff'>"+currentList[i].description+"</td>"+
						"<td>" +
				  			"<input type='button' value='Delete' onclick='deleteById("+currentList[i].id+");'>"+
				  	   "</td>"	+
				  		"<td>"+
				  			"<input type='button' id='myBtn' value='Modifica' onclick='openDetailDialogUpdate("+currentList[i].id+");'>"+
				  		"</td>" +
				  "<tr>";
		
		bodyTable += tmp;
	}

	var endTable ="</table>";
	$('#tableList').html(startTable + bodyTable + endTable);
}



function openDetailDialogUpdate(id) {

	console.log("id: "+id);
	$('#editButton').show();
	$('#updateLabel').show();
	$('#insertButton').hide();
	$('#insertLabel').hide();

	$('#labelError').hide();
	$('#label').css("background-color", "white");
	$('#levelError').hide();
	$('#level').css("background-color", "white");
	
	getSurveyFromServer(id);
	
	$('#detailModal').show();

}

function update() {

	var data = {	
					"id": $('#idSurvey').val(),
					"label": $('#label').val(), 
					"description": $('#description').val(),
			   };

	if((validateForm(data.label,data.description))) {

		$.ajax({
			type: "POST",
			url: resourceApi,
			data: data,
			dataType: 'json',
			success: function(returnMsg)
			{
				console.log("OK"+returnMsg);

				if(returnMsg == true) {
					refreshTable();
				}
				closeDetailDialog();
			},
			error: function()
			{
				console.log("KO");
				closeDetailDialog();
			}
		});
	}
}

function deleteById(id) {

	console.log("deleteById Id: "+id);
	var dataDelete = {"id":id};
	
	$.ajax({
		type: "POST",
		url: resourceApi,
		data: dataDelete,
		dataType: 'json',
		success: function(returnMsg)
		{
			console.log("OK"+returnMsg);
			
			if(returnMsg == true) {
				refreshTable();
			}
		},
		error: function()
		{
			console.log("KO");
		}
	});
}

function openDetailDialogInsert() {

	$('#editButton').hide();
	$('#updateLabel').hide();
	$('#insertButton').show();
	$('#insertLabel').show();

	$('#labelError').hide();
	$('#label').css("background-color", "white");
	$('#levelError').hide();
	$('#level').css("background-color", "white");
	
	$('#label').val("");
	$('#description').val("");
	$('#level').val("");
	
	$('#detailModal').show();
}



function validateForm(label,description) {
	console.log("validateForm");
	console.log(label);
	console.log(description);

	if (label.length < 2) {
		$('#labelError').show();
		$('#label').css("background-color", "red");
		return false;
	} 

	return true;
}