function closeDetailDialog() {

	$('#detailModal').hide();
	
}

function getEmployeeFromServer(id) {
	
	console.log("getEmployeeFromServer: "+id);

	var url =	employeeApi + id;
	console.log(url);
	$.ajax({
		type : 'GET',
		url : url,
		dataType : 'json',
		success : function(data, textStatus, jQxhr) {
			console.log("OK"+data);
			$('#idEmployee').val(data.id);
			$('#user_id').val(data.user_id);
			$('#mobile').val(data.mobile);
			$('#domicile_city').val(data.domicile_city);
			$('#domicile_street_name').val(data.domicile_street_name);
			$('#domicile_street_number').val(data.domicile_house_number);
			$('#cv_external_path').val(data.cv_external_path);	
		},
		failure : function(data, textStatus, jQxhr) {
			console.log("KO" + data);
		}
	});
}

function createTable(currentList) {
	
	console.log("Invocato refreshTable()");
	var startTable = "<table> " +
					"<tr> " +
					"<th>USERID</th>"+
					"<th>MOBILE</th>"+
					"<th>CITY</th>"+
					"<th>STREETNAME</th>"+
					"<th>STREETNUMBER</th>"+
					"<th>CVEXTERNALPATH</th>"+
						"<th></th>"+
						"<th></th>"+
					"</tr>" ;
	
	var bodyTable = "";
	
	for(var i=0 ;i<currentList.length ; i++) {
		
		var tmp ="<tr>" +
						"<td align='right' bgcolor='#ffffff'>"+currentList[i].user_id+"</td>"+
						"<td align='right' bgcolor='#ffffff'>"+currentList[i].mobile+"</td>"+
						"<td align='right' bgcolor='#ffffff'>"+currentList[i].domicile_city+"</td>"+
						"<td align='right' bgcolor='#ffffff'>"+currentList[i].domicile_street_name+"</td>"+
						"<td align='right' bgcolor='#ffffff'>"+currentList[i].domicile_house_number+"</td>"+
						"<td align='right' bgcolor='#ffffff'>"+currentList[i].cv_external_path+"</td>"+
						"<td>" +
				  			"<input type='button' value='Delete' onclick='deleteById("+currentList[i].id+");'>"+
				  	   "</td>"	+
				  		"<td>"+
				  			"<input type='button' id='myBtn' value='Modifica' onclick='openDetailDialogUpdate("+currentList[i].id+");'>"+
				  		"</td>" +
				  "<tr>";
		
		bodyTable += tmp;
	}

	var endTable ="</table>";
	$('#tableList').html(startTable + bodyTable + endTable);
}

function refreshTable()  {
	
	console.log("refreshTable() chiamato");
	$.ajax({
		type : 'GET',
		url : employeeApi,
		dataType : 'json',
		success : function(data, textStatus, jQxhr) {
			console.log("OK"+data);
			createTable(data);
			
		},
		failure : function(data, textStatus, jQxhr) {
			console.log("KO" + data);
		}
	});
}	

function openDetailDialogUpdate(id) {

	console.log("id: "+id);
	$('#editButton').show();
	$('#updateLabel').show();
	$('#insertButton').hide();
	$('#insertLabel').hide();

	$('#labelError').hide();
	$('#label').css("background-color", "white");
	$('#levelError').hide();
	$('#level').css("background-color", "white");
	
	getEmployeeFromServer(id);
	
	$('#detailModal').show();
}

function update() {

	var data = {	
					"id":  $('#idEmployee').val(),
					"user_id" : $('#user_id').val(),
					"mobile" : $('#mobile').val(),
					"domicile_city" : $('#domicile_city').val(),
					"domicile_street_name" : $('#domicile_street_name').val(),
					"domicile_street_number" : $('#domicile_street_number').val(),
					"cv_external_path" : $('#cv_external_path').val(),
				};

	if((validateForm(data.label,data.description,data.level))) {

		$.ajax({
			type: "POST",
			url: employeeApi,
			data: data,
			dataType: 'json',
			success: function(returnMsg)
			{
				console.log("OK"+returnMsg);

				if(returnMsg == true) {
					refreshTable();
				}
				closeDetailDialog();
			},
			error: function()
			{
				console.log("KO");
				closeDetailDialog();
			}
		});
	}
}


function deleteById(id) {

	console.log("deleteById Id: "+id);
	
	$.ajax({
		type: "POST",
		url: employeeApi + id,
		dataType: 'json',
		success: function(returnMsg)
		{
			console.log("OK"+returnMsg);
			
			if(returnMsg == true) {
				refreshTable();
			}
		},
		error: function()
		{
			console.log("KO");
		}
	});
}

function openDetailDialogInsert() {

	$('#editButton').hide();
	$('#updateLabel').hide();
	$('#insertButton').show();
	$('#insertLabel').show();

	$('#labelError').hide();
	$('#label').css("background-color", "white");
	$('#levelError').hide();
	$('#level').css("background-color", "white");
	
	$('#label').val("");
	$('#description').val("");
	$('#level').val("");
	
	$('#detailModal').show();
}

function insert() {

	var data = {	"label": $('#label').val(), 
					"description": $('#description').val(),
					"level": $('#level').val()
			   };

	if((validateForm(data.label,data.description,data.level))) {

		$.ajax({
			type: "POST",
			url: employeeApi,
			data: data,
			dataType: 'json',
			contentType: 'application/json',
			success: function(returnMsg)
			{
				console.log("OK"+returnMsg);
				
				if(returnMsg == true) {
					refreshTable();
				}
				$('#detailModal').hide();
			},
			error: function()
			{
				console.log("KO");
				$('#detailModal').hide();
			}
		});
	}
}

function validateForm(label,description,level) {
	
	console.log("validateForm");
	console.log(label);
	console.log(description);
	console.log(level);

	if (level > 0) {
		if (label.length < 2) {
			$('#labelError').show();
			$('#label').css("background-color", "red");
			return false;
		} 
	} else {
		$('#levelError').show();
		$('#level').css("background-color", "red");
		return false;
	}

	return true;
}