var modal = document.getElementById('detailModal');
	
function closeDetailDialog() {
	document.getElementById('detailModal').style.display = "none"; 
}

function createTable() {
	console.log("createTable invocato");
	var startTable="<table><tr><th>Domicile City</th>" +
	"<th>Domicile Street Name</th>" +
	"<th>Domicile House Number</th>" +
	"<th>Study Qualification</th>" +
	"<th>Graduate</th>" +
	"<th>High Graduate</th>" +
	"<th>Still High Study</th>" +
	"<th>Mobile</th>" +
	"<th>CV External Path</th></tr>";
//	var startTable="<table><tr><th>candidate.table.domicile_city</th>" +
//			"<th>candidate.table.domicile_street_name</th>" +
//			"<th>candidate.table.domicile_house_number</th>" +
//			"<th>candidate.table.study_qualification</th>" +
//			"<th>candidate.table.graduate</th>" +
//			"<th>candidate.table.high_graduate</th>" +
//			"<th>candidate.table.still_high_study</th>" +
//			"<th>candidate.table.mobile</th>" +
//			"<th>candidate.table.cv_external_path</th></tr>";
	var bodyTable="";
	for(var i=0; i<currentList.length; i++){
		var tmp="<tr><td align='right' bgcolor='#ffffff'>" +currentList[i].domicile_city+ "</td>" +
				"<td align='right' bgcolor='#ffffff'>" +currentList[i].domicile_street_name+ "</td>" +
				"<td align='right' bgcolor='#ffffff'>" +currentList[i].domicile_house_number+ "</td>" +
				"<td align='right' bgcolor='#ffffff'>" +currentList[i].study_qualification+ "</td>" +
				"<td align='right' bgcolor='#ffffff'>" +currentList[i].graduate+ "</td>" +
				"<td align='right' bgcolor='#ffffff'>" +currentList[i].high_graduate+ "</td>" +
				"<td align='right' bgcolor='#ffffff'>" +currentList[i].still_high_study+ "</td>" +
				"<td align='right' bgcolor='#ffffff'>" +currentList[i].mobile+ "</td>" +
				"<td align='right' bgcolor='#ffffff'>" +currentList[i].cv_external_path+ "</td>" +
				"<td>" +
//				"<form id='candidateFormDelete' action='" + deleteAction + "' method='POST'>" +
//				"<input type='hidden' name='id' id='idCandidateDelete' value=''>" +
				"<input type='button' value='Delete' onclick='deleteById(" +currentList[i].id+ ");'>" +
//				"</form>" +
				"</td>" +
				"<td><input type='button' id='myBtn' value='Edit' onclick='openDetailDialogUpdate(" +currentList[i].id+ ");'></td></tr>";
		bodyTable+=tmp;
	}
	var endTable="</table>";
	document.getElementById("tableList").innerHTML = startTable+bodyTable+endTable;
}

function refreshTable() {
	console.log("refreshTable() chiamato");
	$.ajax({
		type : 'GET',
		url : candidateApi,
		dataType : 'json',
		success : function(data, textStatus, jQxhr) {
			console.log("OK"+data);
			createTable(data);
			
		},
		failure : function(data, textStatus, jQxhr) {
			console.log("KO" + data);
		}
	});
}
		
function openDetailDialogUpdate(id) {
	console.log("id: "+id);
//	document.getElementById("editButton").style.display = 'block';
//	document.getElementById("updateLabel").style.display = 'block';
//	document.getElementById("insertButton").style.display = 'none';
//	document.getElementById("insertLabel").style.display = 'none';
	$('#editButton').show();
	$('#updateLabel').show();
	$('#insertButton').hide();
	$('#insertLabel').hide();
	getEntityFromServer(id);
	
//	if(currentObj!=null) {
//		$("#idCandidate").val(currentObj.idCandidate);
//		$("#domicile_city").val(currentObj.domicile_city);
//		$("#domicile_street_name").val(currentObj.domicile_street_name);
//		$("#domicile_house_number").val(currentObj.domicile_house_number);
//		$("#study_qualification").val(currentObj.study_qualification);
//		$("#mobile").val(currentObj.mobile);
//		$("#cv_external_path").val(currentObj.cv_external_path);
//		if(currentObj.graduate==true)
//			$("#graduate").prop('checked', true);
//		else
//			$("#graduate").prop('checked', false);
//		if(currentObj.high_graduate==true)
//			$("#high_graduate").prop('checked', true);
//		else
//			$("#high_graduate").prop('checked', false);
//		if(currentObj.still_high_study==true)
//			$("#still_high_study").prop('checked', true);
//		else
//			$("#still_high_study").prop('checked', false);	
//	}
//	document.getElementById("detailModal").style.display = 'block';
	$('#detailModal').show();
}

function getEntityFromServer(id) {
	console.log("getRoleFromServer: "+id);

	var url = candidateApi + id;
	console.log(url);
	$.ajax({
		type : 'GET',
		url : url,
		dataType : 'json',
		success : function(data, textStatus, jQxhr) {
			console.log("OK"+data);
			$("#idCandidate").val(data.idCandidate);
			$("#domicile_city").val(data.domicile_city);
			$("#domicile_street_name").val(data.domicile_street_name);
			$("#domicile_house_number").val(data.domicile_house_number);
			$("#study_qualification").val(data.study_qualification);
			$("#mobile").val(data.mobile);
			$("#cv_external_path").val(data.cv_external_path);
			if(data.graduate==true)
				$("#graduate").prop('checked', true);
			else
				$("#graduate").prop('checked', false);
			if(data.high_graduate==true)
				$("#high_graduate").prop('checked', true);
			else
				$("#high_graduate").prop('checked', false);
			if(data.still_high_study==true)
				$("#still_high_study").prop('checked', true);
			else
				$("#still_high_study").prop('checked', false);
		},
		failure : function(data, textStatus, jQxhr) {
			console.log("KO" + data);
		}
	});
}

function update() {
	var g = $('#graduate:checked').val() ? true : false;
	var hg = $('#high_graduate:checked').val() ? true : false;
	var shs = $('#still_high_study:checked').val() ? true : false;
	var data = {"idCandidate" : $("#idCandidate").val(),
			"domicile_city" : $("#domicile_city").val(),
			"domicile_street_name" : $("#domicile_street_name").val(),
			"domicile_house_number" : $("#domicile_house_number").val(),
			"study_qualification" : $("#study_qualification").val(),
			"mobile" : $("#mobile").val(),
			"cv_external_path" : $("#cv_external_path").val(),
			"graduate" : g,
			"high_graduate" : hg,
			"still_high_study" : shs
	};
	$.ajax({
	      type: "POST",
	      url: candidateApi,
	      data: data,
	      dataType: 'json',
	      success: function(returnMsg) {
	        console.log("OK"+returnMsg);
	        if(returnMsg==true) {
	        	refreshTable();
	        	closeDetailDialog()
	        }
	      },
	      error: function() {
	    	  console.log("KO");
	      }
	    });
}
		
function deleteById(id) {
	var data = {"id" : id};
	$.ajax({
	      type: "POST",
	      url: candidateApi + id,
	      data: data,
	      dataType: 'json',
	      success: function(returnMsg) {
	        console.log("OK"+returnMsg);
	        if(returnMsg==true) {
	        	refreshTable();
	        }
	      },
	      error: function() {
	    	  console.log("KO");
	      }
	    });
}
		
function openDetailDialogInsert() {
//	document.getElementById("editButton").style.display = 'none';
//	document.getElementById("updateLabel").style.display = 'none';
//	document.getElementById("insertButton").style.display = 'block';
//	document.getElementById("insertLabel").style.display = 'block';
	$('#editButton').hide();
	$('#updateLabel').hide();
	$('#insertButton').show();
	$('#insertLabel').show();
	
	$("#domicile_city").val('');
	$("#domicile_street_name").val('');
	$("#domicile_house_number").val('');
	$("#study_qualification").val('');
	$("#mobile").val(currentObj.mobile);
	$("#cv_external_path").val('');
	
	//TODO
	$('#graduate').prop('checked',false);
//	$('#graduate')[0].checked = false;
//	$('#graduate').prop("disabled", false );
	$("#high_graduate").prop('checked',false);
	$("#still_high_study").prop('checked',false);
	
//	document.getElementById("graduate").checked= '';
//	document.getElementById("high_graduate").checked= '';
//	document.getElementById("still_high_study").checked='';	
	document.getElementById("detailModal").style.display = 'block';
}
		
function insert() {
	var g = $('#graduate:checked').val() ? true : false;
	var hg = $('#high_graduate:checked').val() ? true : false;
	var shs = $('#still_high_study:checked').val() ? true : false;
	var data = {"domicile_city" : $("#domicile_city").val(),
			"domicile_street_name" : $("#domicile_street_name").val(),
			"domicile_house_number" : $("#domicile_house_number").val(),
			"study_qualification" : $("#study_qualification").val(),
			"mobile" : $("#mobile").val(),
			"cv_external_path" : $("#cv_external_path").val(),
			"graduate" : g,
			"high_graduate" : hg,
			"still_high_study" : shs,
			"user_id":1 //TODO da cambiare
	};
	$.ajax({
	      type: "POST",
	      url: candidateApi,
	      data: data,
	      dataType: 'json',
	      success: function(returnMsg) {
	        console.log("OK"+returnMsg);
	        if(returnMsg==true) {
	        	refreshTable();
	        	closeDetailDialog();
	        }
	      },
	      error: function() {
	    	  console.log("KO");
	      }
	    });
}