/**
 * @author marcof
 */
		var modal = document.getElementById('detailModal');
		
		function closeDetailDialog() {

			$('#detailModal').hide();
		}
		
		function getSurveyReplyFromServer(id){
			console.log(" # getSurveyReplyFromServer() STARTED id= "+id)
			
			var xhttp = new XMLHttpRequest();		/* xhttp.onreadystatechange significa "quando mi ha risposto il server"*/
			xhttp.onreadystatechange = function() { /* dichiarazione diuna funzione anonmia xk tanto non userò mai piu in altri punti del codice*/
				if (this.readyState == 4 && this.status == 200) { /* Controllo che lo stato del server sia un buono stato */
					console.log( this.responseText );
					/* assegniamo i campi al nostro JSON */
					currentObj = JSON.parse(this.responseText);
					
					/** da togliere*/
					$("#idSurvRep").val(currentObj.id);
					/* Prepopolo */
					$("#user_id").val(currentObj.user_id);
					$("#survey_id").val(currentObj.survey_id);
					$("#starttime").val(currentObj.starttime.year + "-" + currentObj.starttime.month +"-" + currentObj.starttime.day);
					$("#endtime").val(currentObj.endtime.year + "-" + currentObj.endtime.month +"-" + currentObj.starttime.day);
					$("#answer").val(currentObj.answer);
					$("#pdffilename").val(currentObj.pdffilename);
					$("#points").val(currentObj.points);
					console.log("##### id= " + $("#idSurvRep").val());
				}
			};
			xhttp.open("GET", surveyReplyapi + id, true); /* definiscio cosa deve fare la chimata*/
			xhttp.send(); /* effettuo la chiamata */
		}
		
		function createTable() {
			console.log(" # createTable() STARTED");
			var startTable = "<table><tr><th>surveyreply.table.usid</th><th>surveyreply.table.survid</th><th>surveyreply.table.startt</th><th>surveyreply.table.endt</th><th>surveyreply.table.pdfname</th><th>surveyreply.table.ans</th><th>surveyreply.table.poin</th><th></th><th></th></tr>"
			var bodyTable = "";
			for (var i = 0; i <currentList.length; i++)
			{
				var tmp = "<tr><td align='right' bgcolor='#ffffff'>"+ currentList[i].user_id +"</td>"
		        	 +"<td align='right' bgcolor='#ffffff'>"+ currentList[i].survey_id +"</td>"
		        	 +"<td align='right' bgcolor='#ffffff'>"+ currentList[i].starttime.year +"/"+  currentList[i].starttime.month + "/"+ currentList[i].starttime.day +"</td>"
		        	 +"<td align='right' bgcolor='#ffffff'>"+ currentList[i].endtime.year +"/"+  currentList[i].endtime.month + "/"+ currentList[i].endtime.day +"</td>"
		        	 +"<td align='right' bgcolor='#ffffff'>"+ currentList[i].pdffilename +"</td>"
		        	 +"<td align='right' bgcolor='#ffffff'>"+ currentList[i].answers +"</td>"
		        	 +"<td align='right' bgcolor='#ffffff'>"+ currentList[i].points +"</td>"
		        	 +"<td>"
		        	 +"<input type='button' value='surveyreply.button.delete' onclick='deleteById("+ currentList[i].id +");'>"
		        	 +"</td>"
		        	 +"<td>" 
		        	 +"<input type='button' id='myBtn' value='surveyreply.button.modify' onclick='openDetailDialogUpdate("+ currentList[i].id +");'>" 
		        	 +"</td>" 
		        	 +"<tr>"
			
		        	 bodyTable += tmp;
			}
			var endTable = "</table>";
			document.getElementById("tableList").innerHTML = startTable + bodyTable + endTable; /* provvede a creare HTML e lo mette dentro all'elemnto indicizzato con "tableList", dunque gli passeremo una stringona che contine tutto il codice HTML */

			
		}
		
		function refreshTable(){
			console.log(" # getALLSurveyReply() STARTED")
			var xhttp = new XMLHttpRequest();		
			xhttp.onreadystatechange = function() { 
				if (this.readyState == 4 && this.status == 200) { 
					console.log( this.responseText );
					currentList = JSON.parse(this.responseText);
					createTable();	
				}
			};
			xhttp.open("GET", surveyReplyapi , true); 
			xhttp.send();
		}
		
		function openDetailDialogUpdate(id) {
		
			console.log(" # openDetailDialogUpdate() STARTED id= "+ id);
			
			$("#editButton").show();
			$("#updateLabel").show();
			$("#insertButton").hide();
			$("#insertLabel").hide();
			
			getSurveyReplyFromServer(id); /* Questa funzione è asincrona, quindi quando parte, il resto del codice va avnti, qundue non posso 
												aspettarmi di avere i dati che produce già alla riga successiva */
			
//			if(currentObj!=null) {
//				document.getElementById("id").value = currentObj.id;
//				/* Prepopolo */
//				document.getElementById("user_id").value = currentObj.user_id;
//				document.getElementById("survey_id").value = currentObj.survey_id;
//				document.getElementById("starttime").value = currentObj.starttime;	
//				document.getElementById("endtime").value = currentObj.endtime;
//				document.getElementById("answer").value = currentObj.answer;
//				document.getElementById("pdffilename").value = currentObj.pdffilename;
//				document.getElementById("points").value = currentObj.points;
				
//				$("id").val(currentObj.id);
//				/* Prepopolo */
//				$("#user_id").val(currentObj.user_id);
//				$("#survey_id").val(currentObj.survey_id);
//				$("#starttime").val(currentObj.starttime.year + "-" + currentObj.starttime.month +"-" + currentObj.starttime.day);
//				$("#endtime").val(currentObj.endtime.year + "-" + currentObj.endtime.month +"-" + currentObj.starttime.day);
//				$("#answer").val(currentObj.answer);
//				$("#pdffilename").val(currentObj.pdffilename);
//				$("#points").val(currentObj.points);
//			}
			
			/* Dopo aver predisposto tutta la form, la rendo visibile */
			document.getElementById("detailModal").style.display = 'block';
		}
		
		function update() {
			var daAggiornare = {
					"id":$('#idSurvRep').val(),
					"user_id":$('#user_id').val(),
					"survey_id":$('#survey_id').val(),
					"starttime":$('#starttime').val(),
					"endtime":$('#endtime').val(),
					"answer":$('#answer').val(),
					"pdffilename":$('#pdffilename').val(),
					"points":$('#points').val()
					}
			console.log("##### id= " + daAggiornare.id);
			
			$.ajax({
			      type: "POST",// tipo di chiamata
			      url: surveyReplyapi,// url di chiamata
			      data: daAggiornare,// passaggio di dati
			      dataType: 'json',
			      success: function(returnMsg)
			      {
			        console.log("OK, returnMsg= "+returnMsg); /*se funge esegue la funzione anonima */
			        if (returnMsg==true)
			        	{
			        		refreshTable();
			        	}
			      },
			      error: function()
			      {
			    	  console.log("KO");
			      }
			    });
			
//			var id = document.getElementById("id").value;
//			var user_id = document.getElementById("user_id").value;
//			var survey_id = document.getElementById("survey_id").value;
//			var start = document.getElementById("starttime").value;
//			var end = document.getElementById("endtime").value;
//			var answer = document.getElementById("answer").value;
//			var pdfname = document.getElementById("pdffilename").value;
//			var points = document.getElementById("points").value;
						
//			if(!(validateForm(user_id,survey_id,start,end))) {		
//	 				return
//	 		}
			
//			document.getElementById("surveyrepiesForm").action = surveyReplyapi;
//			document.getElementById("surveyrepiesForm").submit();
		}
		
		
		function deleteById(id) {
			console.log(" # deleteById()");

			/* Oggetto jsin che contiente id da cancellare */
			var daEliminare = {"id":id}
			$.ajax({
			      type: "POST",// tipo di chiamata
			      url: surveyReplyapi,// url di chiamata
			      data: daEliminare,// passaggio di dati
			      dataType: 'json',
			      success: function(returnMsg)
			      {
			        console.log("OK, returnMsg= "+returnMsg); /*se funge esegue la funzione anonima */
			        if (returnMsg==true)
			        	{
			        		refreshTable();
			        	}
			      },
			      error: function()
			      {
			    	  console.log("KO");
			      }
			    });
			
//			document.getElementById("idDelete").value = id;
//			var id1 = document.getElementById("idDelete").value;
//			
//			document.getElementById("surveyrepiesDelete"+id).submit();
		}
		
		function openDetailDialogInsert() {
			
//			document.getElementById("editButton").style.display = 'none';
//			document.getElementById("updateLabel").style.display = 'none';
//			document.getElementById("insertButton").style.display = 'block';
//			document.getElementById("insertLabel").style.display = 'block';
			$("#editButton").hide();
			$("#updateLabel").hide();
			$("#insertButton").show();
			$("#insertLabel").show();
			
			/* Ritorno la tabella dell'inserimento bianca */
//			document.getElementById("UserIdError").style.display = 'none';
//			document.getElementById("user_id").style.backgroundColor = 'white';
//			document.getElementById("SurveyIdError").style.display = 'none';
//			document.getElementById("survey_id").style.backgroundColor = 'white';
//			document.getElementById("StartTimeError").style.display = 'none';
//			document.getElementById("starttime").style.backgroundColor = 'white';
//			document.getElementById("EndTimeError").style.display = 'none';
//			document.getElementById("endtime").style.backgroundColor = 'white';
			$("#UserIdError").hide();
			$("#user_id").val('white');
			$("#SurveyIdError").hide();
			$("#survey_id").val('white');
			$("#StartTimeError").hide();
			$("#starttime").val('white');
			$("#EndTimeError").hide();
			$("#endtime").val('white');
			
//			document.getElementById("detailModal").style.display = 'block';
			$("#detailModal").show();
			
//			document.getElementById("user_id").value = "";
//			document.getElementById("survey_id").value = "";
//			document.getElementById("starttime").value = "";
//			document.getElementById("endtime").value = "";
//			document.getElementById("answer").value = "";
//			document.getElementById("pdffilename").value = "";
//			document.getElementById("points").value = "";
			$("#user_id").val("");
			$("#survey_id").val("");
			$("#starttime").val("");
			$("#endtime").val("");
			$("#answer").val("");
			$("#pdffilename").val("");
			$("#points").val("");
			
		}
		
		function insert() {
			console.log(" # insert()");

			var daInserire = {
					"user_id":$('#user_id').val(),
					"survey_id":$('#survey_id').val(),
					"starttime":$('#starttime').val(),
					"endtime":$('#endtime').val(),
					"answer":$('#answer').val(),
					"pdffilename":$('#pdffilename').val(),
					"points":$('#points').val()
					}
			
			$.ajax({
			      type: "POST",// tipo di chiamata
			      url: surveyReplyapi,// url di chiamata
			      data: daInserire,// passaggio di dati
			      dataType: 'json',
			      success: function(returnMsg)
			      {
			        console.log("OK, returnMsg= "+returnMsg); /*se funge esegue la funzione anonima */
			        if (returnMsg==true)
			        	{
			        		refreshTable();
			        	}
			      },
			      error: function()
			      {
			    	  console.log("KO");
			      }
			    });
			
//			var user_id = document.getElementById("user_id").value;  equivalente a   $('#user_id').val()
//			var survey_id = document.getElementById("survey_id").value;
//			var start = document.getElementById("starttime").value;
//			var end = document.getElementById("endtime").value;
//			var answer = document.getElementById("answer").value;
//			var pdfname = document.getElementById("pdffilename").value;
//			var points = document.getElementById("points").value;
			
// 			if(!(validateForm(user_id,survey_id,start,end))) {	
// 				return
// 			}
//			
//			document.getElementById("surveyrepiesForm").action = surveyReplyapi;
//			document.getElementById("surveyrepiesForm").submit();
		
		}
		
		function validateForm(user_id,survey_id,start,end) {
			console.log(" ##### validateForm() STARTED");
			console.log(user_id);
			console.log(survey_id);
			console.log(start);
			console.log(end);
			
			if ( user_id.length <= 0 || survey_id.length <= 0 || start.length <= 0 || end.length <= 0){
				if (user_id.length <= 0) {
//					document.getElementById("UserIdError").style.display = 'block';
//					document.getElementById("user_id").style.backgroundColor = 'red';
					$("#UserIdError").show();
					$("#user_id").val('red');
				}
				if (survey_id.length <= 0) {
//					document.getElementById("SurveyIdError").style.display = 'block';
//					document.getElementById("survey_id").style.backgroundColor = 'red';
					$("#SurveyIdError").show();
					$("#survey_id").val('red');
				}
				if (start.length <= 0) {
//					document.getElementById("StartTimeError").style.display = 'block';
//					document.getElementById("starttime").style.backgroundColor = 'red';
					$("#StartTimeError").show();
					$("#starttime").val('red');
				}
				if (end.length <= 0) {
//					document.getElementById("EndTimeError").style.display = 'block';
//					document.getElementById("endtime").style.backgroundColor = 'red';
					$("#EndTimeError").show();
					$("#endtime").val('red');
				}
				return false;
			}
			
			return true;
		}