/**
 * 
 */
function closeDetailDialog() {

	$('#detailModal').hide();
}

function getUserFromServer(id){
	console.log("getUserFromServer: "+id);
//	funzione anonima che deve essere eseguita quando il server mi risponde 
//	sul cambiamento di stato eseguo questa funzione 

	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {

//			se lo stato è 200 il server mi stampa la risposta

			this.responseText;
			console.log(this.responseText);
			currentOBJ= ( JSON.parse(this.responseText));      
		}
	};
//	url della chiamata alla servlet
//	fai una chiamata in get a questo url

	xhttp.open("GET", userApi + id, true); 
	xhttp.send();

}

function createTable(){
	console.log("invocato metodo refreshTable()");
	var startable = 
		"<table>" +
			"<tr>" +
				"<th>user.table.nome</th>" +
				"<th>user.table.cognome</th><th>user.table.email</th>" +
				"<th>user.table.password</th><th>user.table.compleanno</th>" +
				"<th>user.table.registrazione</th><th>user.table.ruolo</th>" +
				"<th>user.table.immagine</th<th colspan=\"2\">user.table.azione</th></tr>";
	var bodyTable = " ";
	for (var i=0; i< currentList.length; i++){
	
		var tmp=
			"<tr>" +
				"<td align='right' bgcolor='#ffffff'>"+ currentList[i].firstname + "</td>" +
				"<td align='right' bgcolor='#ffffff'>"+ currentList[i].lastname + "</td>" +
				"<td align='right' bgcolor='#ffffff'>"+ currentList[i].email + "</td>" +
				"<td align='right' bgcolor='#ffffff'>"+ currentList[i].password + "</td>" +
				"<td align='right' bgcolor='#ffffff'>"+ currentList[i].dateOfBirth + "</td> " +
				"<td align='right' bgcolor='#ffffff'>"+ currentList[i].regdate.day + "-" + currentList[i].regdate.month + "-" + currentList[i].regdate.year + "</td>" +
				"<td align='right' bgcolor='#ffffff'>"+ currentList[i].role + "</td>" +
				"<td align='right' bgcolor='#ffffff'>"+ currentList[i].imgpath + "</td>" +
				"<td>" +
					"<input type='button' value='Delete' onclick='deleteById("+ currentList[i].id + ");'></td>" +
				"<td>" +
					"<input type='button' id='myBtn' value='Modify' onclick='openDetailDialogUpdate("+ currentList[i].id +");'>"+
				"</td>" +
			"</tr>";
		
		bodyTable += tmp;
	}
	var endtable="</table>";
	document.getElementById("tableList").innerHTML = startable + bodyTable + endtable;
}

function refreshTable(){
	console.log("getAllEntities chiamato");
	var xhttp = new XMLHttpRequest();
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			console.log(this.responseText);
			currentList = JSON.parse(this.responseText);
			createTable();
		}
	};
//	url della chiamata alla servlet
//	fai una chiamata in get a questo url
	xhttp.open("GET", userApi , true); 
	xhttp.send();

}		

function openDetailDialogUpdate(id) {

	console.log("id: "+id);
	$('#editButton').show();
	$('#updateLabel').show();
	$('#insertButton').hide();
	$('#insertLabel').hide();

	getUserFromServer(id);

	if(currentOBJ != null){

//		$("#id").val(currentOBJ.id);
		document.getElementById("id").value = currentOBJ.id;

		document.getElementById("nome").value = currentOBJ.firstname;
		document.getElementById("cognome").value = currentOBJ.lastname;
		document.getElementById("email").value = currentOBJ.email;
		document.getElementById("password").value = currentOBJ.password;
		document.getElementById("data").value = currentOBJ.dateOfBirth;
		document.getElementById("registrazione").value = currentOBJ.regdate;
		document.getElementById("ruolo").value = currentOBJ.role;
		document.getElementById("immagine").value = currentOBJ.imgpath;	
	}

	document.getElementById("detailModal").style.display = 'block';	

}

function update() {
	console.log(" ### update() STARTED ");
	var toUpdate = {
//			"id" : $('#id').val(),
			"email" : $('#email').val(),
			"password" : $('#password').val(),
			"firstname" : $('#nome').val(),
			"lastname" : $('#cognome').val(),
			"dateOfBirth" : $('#data').val(),
			"regdate" : $('#registrazione').val(),
			"role" : $('#ruolo').val(),
			"imgpath" : $('#immagine').val()
	};
	console.log("id letto? " + id);

	$.ajax({
		type: "POST",
		url: userApi,
		data: toUpdate,
		dataType: 'json',
		success: function(returnMsg)
		{
			console.log("OK" + returnMsg); //if return message uguale a true allora refresha!
			if(returnMsg== true){
				refreshTable();
			}
			closeDetailDialog();
		},
		error: function()
		{
			console.log("KO");
			closeDetailDialog();
		}
	});
}


function deleteById(id) {

	console.log("deleteById Id: "+id);
//	var data2 = {"id" :  id};
	/* effettuo una chiamata ajax tramite jquery in metodo post, 
	 * deleteaction e passando un tipo di dato json*/
	$.ajax({
		type: "POST",
		url: userApi + id,
		dataType: 'json',
		success: function(returnMsg)
		{
			console.log("OK" + returnMsg); //if return message uguale a true allora refresha!
			if(returnMsg== true){
				refreshTable();
			}
		},
		error: function()
		{
			console.log("KO");
		}
	});

}

function openDetailDialogInsert() {

	$('#editButton').hide();
	$('#updateLabel').hide();
	$('#insertButton').show();
	$('#insertLabel').show();
	
	$('#nome').val("");
	$('#cognome').val("");
	$('#email').val("");
	$('#password').val("");
	$('#data').val("");
	$('#registrazione').val("");
	
	$('#detailModal').show();
}

function insert() {
	var data = {
			"email" : $('#email').val(),
			"password" : $('#password').val(),
			"firstname" : $('#nome').val(),
			"lastname" : $('#cognome').val(),
			"dateOfBirth" : $('#data').val(),
			"regdate" : $('#registrazione').val(),
			"role" : $('#ruolo').val(),
			"imgpath" : $('#immagine').val()
	};

	$.ajax({
		type: "POST",
		url: userApi,
		data: data,
		dataType: 'json',
		contentType: 'application/json',
		success: function(returnMsg)
		{
			console.log("OK" + returnMsg); //if return message uguale a true allora refresha!
			if(returnMsg== true){
				refreshTable();
			}
			closeDetailDialog();
		},
		error: function()
		{
			console.log("KO");
			closeDetailDialog();
		}
	});

}

function validateForm(label,description,level) {
	console.log("validateForm");
	console.log(label);
	console.log(description);
	console.log(level);

	if (level > 0) {
		if (label.length < 2) {
			document.getElementById("labelError").style.display = 'block';
			document.getElementById("label").style.backgroundColor = 'red';
			return false;
		} 
	} else {
		document.getElementById("levelError").style.display = 'block';
		document.getElementById("level").style.backgroundColor = 'red';
		return false;
	}

	return true;
}