/**
 * JavaScript for question's entyties.
 */
		var modal = document.getElementById('detailModal');
		

		window.onclick = function(event) {
		    if (event.target == modal) {
		        modal.style.display = "none";
		    }
		}
		
		function closeDetailDialog() {
			console.log("invocato closeDetailDialog");
			$('#detailModal').hide();
//			document.getElementById('detailModal').style.display = "none";
		}
		
		function createTable(){
			console.log("Chiamato createTable");
			var startTable = "<table><tr><th>question.table.label</th><th>question.table.description</th><th>question.table.ansa</th><th></th><th></th></tr>"
			var bodyTable = "";
			for(var i=0; i<currentList.length; i++){
				var tmp ="<tr><td align='right' bgcolor='#ffffff'>"+currentList[i].label+"</td>"+
				"<td align='right' bgcolor='#ffffff'>"+currentList[i].description+"</td>"+
				"<td align='right' bgcolor='#ffffff'>"+currentList[i].ansa+"</td>"+
				"<td>"+
//				"<form id='questionFormDelete"+currentList[i].id+"' action='"+deleteAction+"' method='POST'>"+
//				"<input type='hidden' name='id' id='idQuestionDelete' value='"+currentList[i].id+"'>"+
				"<input type='button' value='Delete' onclick='deleteById("+currentList[i].id+");'>"+
//				"</form>"+
				"</td>"+
				"<td><input type='button' id='myBtn' value='Modifica' onclick='openDetailDialogUpdate("+currentList[i].id+");'>"+
				"</td><tr>";
				bodyTable += tmp;
			}	
			var endTable = "</table>"
			$('#tableList').html(startTable + bodyTable + endTable);
		}
		
		function getEntityFromServer(id){
			console.log("getEntityFromServer "+id);
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
//				stato 200 indica che e' andato tutto a buon fine
				if (this.readyState == 4 && this.status == 200) {
					console.log(this.responseText);
					currentObj=JSON.parse(this.responseText);
//					currentObj=JSON.parse('{\"id\":1, \"label\":\"salutare\", \"description\":\"modi di salutare\", \"ansa\":\"ciao\", \"ansb\":2, \"ansc\":\"prova\", \"ansd\":\"ehi\", \"anse\":null, \"ansf\":null, \"ansg\":null, \"ansh\":null, \"cansa\":true, \"cansb\":false, \"cansc\":false, \"cansd\":true, \"canse\":false, \"cansf\":null, \"cansg\":null, \"cansh\":null, \"fullAnswer\":\"full answer\"}');
					if(currentObj!=null){
						$('#idQuestion').val(currentObj.id);
						$('#label').val(currentObj.label);
						$('#ansa').val(currentObj.ansa);
						$('#ansb').val(currentObj.ansb);
						$('#ansc').val(currentObj.ansc);
						$('#ansd').val(currentObj.ansd);
						$('#anse').val(currentObj.anse);
						$('#ansf').val(currentObj.ansf);
						$('#ansg').val(currentObj.ansg);
						$('#ansh').val(currentObj.ansh);
						if(currentObj.cansa){
							$('#cansa1').prop('checked', true);
						}else if(currentObj.cansa==false){
							$('#cansa2').prop('checked', true);;
						}
						if(currentObj.cansb){
							$('#cansb1').prop('checked', true);;
						}else if(currentObj.cansb==false){
							$('#cansb2').prop('checked', true);;
						}
		 				if(currentObj.cansc){
		 					$('#cansc1').prop('checked', true);;
		 				}else if(currentObj.cansc==false){
		 					$('#cansc2').prop('checked', true);;
		 				}
		 				if(currentObj.cansd){
		 					$('#cansd1').prop('checked', true);;
		 				}else if(currentObj.cansd==false){
		 					$('#cansd2').prop('checked', true);;
		 				}
		 				if(currentObj.canse){
		 					$('#canse1').prop('checked', true);;
		 				}else if(currentObj.canse==false){
		 					$('#canse2').prop('checked', true);;
		 				}
		 				if(currentObj.cansf){
		 					$('#cansf1').prop('checked', true);;
		 				}else if(currentObj.cansf==false){
		 					$('#cansf2').prop('checked', true);;
		 				}
		 				if(currentObj.cansg){
		 					$('#cansg1').prop('checked', true);;
		 				}else if(currentObj.cansg==false){
		 					$('#cansg2').prop('checked', true);;
		 				}
		 				if(currentObj.cansh){
		 					$('#cansh1').prop('checked', true);;
		 				}else if(currentObj.cansh==false){
		 					$('#cansh2').prop('checked', true);;
		 				}
						$('#fullAnswer').val(currentObj.fullAnswer);
					}
				}
			};
			xhttp.open("GET", questionApi + id, true);
			xhttp.send();
		}
		
		function refreshTable(){
			console.log("Chiamato refreshTable");
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function() {
				if (this.readyState == 4 && this.status == 200) {
			    	console.log(this.responseText);
			    	currentList=JSON.parse(this.responseText);
			    	createTable();
				}
			};
			xhttp.open("GET", questionApi, true);
			xhttp.send();
		}
		
		function openDetailDialogUpdate(id) {
			console.log("id: "+id);
			
			$('#editButton').show();
			$('#updateLabel').show();
			$('#insertButton').hide();
			$('#insertLabel').hide();
			$('#idQuestion').val("");
			$('#label').val("");
			$('#description').val("");
			$('#ansa').val("");
			$('#ansb').val("");
			$('#ansc').val("");
			$('#ansd').val("");
			$('#anse').val("");
			$('#ansf').val("");
			$('#ansg').val("");
			$('#ansh').val("");
			$('#fullAnswer').val("");
			console.log("setto prop checked di cansa1");
			$('#cansa1').prop('checked', false);
			$('#cansa2').prop('checked', false);
			$('#cansb1').prop('checked', false);
			$('#cansb2').prop('checked', false);
			$('#cansc1').prop('checked', false);
			$('#cansc2').prop('checked', false);
			$('#cansd1').prop('checked', false);
			$('#cansd2').prop('checked', false);
			$('#canse1').prop('checked', false);
			$('#canse2').prop('checked', false);
			$('#cansf1').prop('checked', false);
			$('#cansf2').prop('checked', false);
			$('#cansg1').prop('checked', false);
			$('#cansg2').prop('checked', false);
			$('#cansh1').prop('checked', false);
			$('#cansh2').prop('checked', false);
			
//			quest'operazione e' asincrona, invoca il metodo e poi continua
			getEntityFromServer(id);
			
			$('#detailModal').show();
		}
		
		function update() {
			console.log("Chiamato update");
			var ca;
			var cb;
			var cc;
			var cd;
			var ce;
			var cf;
			var cg;
			var ch;
			
//			Answer A
			var isChecked1 = $('#cansa1:checked').val() ? true : false;
			var isChecked2 = $('#cansa2:checked').val() ? true : false;

			if (isChecked1 & !isChecked2){
				ca = true;
			}else{
				ca = false;
			}

//			Answer B
			var isChecked3 = $('#cansb1:checked').val() ? true : false;
			var isChecked4 = $('#cansb2:checked').val() ? true : false;

			if (isChecked3 & !isChecked4){
				cb = true;
			}else{
				cb = false;
			}

//			Answer C
			var isChecked5 = $('#cansc1:checked').val() ? true : false;
			var isChecked6 = $('#cansc2:checked').val() ? true : false;

			if (isChecked5 & !isChecked6){
				cc = true;
			}else{
				cc = false;
			}

//			Answer D
			var isChecked7 = $('#cansd1:checked').val() ? true : false;
			var isChecked8 = $('#cansd2:checked').val() ? true : false;

			if (isChecked7 & !isChecked8){
				cd = true;
			}else{
				cd = false;
			}

//			Answer E
			var isChecked9 = $('#canse1:checked').val() ? true : false;
			var isChecked10 = $('#canse2:checked').val() ? true : false;

			if (isChecked9 & !isChecked10){
				ce = true;
			}else{
				ce = false;
			}

//			Answer F
			var isChecked11 = $('#cansf1:checked').val() ? true : false;
			var isChecked12 = $('#cansf2:checked').val() ? true : false;

			if (isChecked11 & !isChecked12){
				cf = true;
			}else{
				cf = false;
			}

//			Answer G
			var isChecked13 = $('#cansg1:checked').val() ? true : false;
			var isChecked14 = $('#cansg2:checked').val() ? true : false;

			if (isChecked13 & !isChecked14){
				cg = true;
			}else{
				cg = false;
			}

//			Answer H
			var isChecked15 = $('#cansh1:checked').val() ? true : false;
			var isChecked16 = $('#cansh2:checked').val() ? true : false;

			if (isChecked15 & !isChecked16){
				ch = true;
			}else{
				ch = false;
			}
			
			var dataUpdate = {
				"id" : $('#idQuestion').val(),
				"label":$('#label').val(),
				"description":$('#description').val(),
				"ansa":$('#ansa').val(),
				"ansb":$('#ansb').val(),
				"ansc":$('#ansc').val(),
				"ansd":$('#ansd').val(),
				"anse":$('#anse').val(),
				"ansf":$('#ansf').val(),
				"ansg":$('#ansg').val(),
				"ansh":$('#ansh').val(),
				"cansa":ca,
				"cansb":cb,
				"cansc":cc,
				"cansd":cd,
				"canse":ce,
				"cansf":cf,
				"cansg":cg,
				"cansh":ch,
				"fullAnswer":$('#fullAnswer').val()
				
			}
			
			$.ajax({
				type: "PUT",
				url: questionApi + $('#idQuestion').val(),
				data: dataUpdate,
				dataType: 'json',
				//esegue l'azione (url) e assegna a returnMsg il messaggio ricevuto dalla Servlet
				success: function(returnMsg){ 
					console.log("Delete OK "+returnMsg);
					if(returnMsg==true){
						$('#detailModal').hide();
						refreshTable();
					}
				},
				error: function(){
					console.log("Delete KO "+returnMsg);
				}
			});
		}
		
		function deleteById(id) {
	
			console.log("deleteById Id: "+id);
			var dataDelete = {
				"id" : id
			}
			
			$.ajax({
				type: "DELETE",
				url: questionApi + id,
				data: dataDelete,
				dataType: 'json',
				//esegue l'azione (url) e assegna a returnMsg il messaggio ricevuto dalla Servlet
				success: function(returnMsg){ 
					console.log("Delete OK "+returnMsg);
					if(returnMsg==true){
						refreshTable();
					}
				},
				error: function(){
					console.log("Delete KO "+returnMsg);
				}
			});
		}
		
		function openDetailDialogInsert() {
			console.log("Invocato openDetailDialogInsert");
			
			$('#editButton').hide();
			$('#updateLabel').hide();
			$('#insertButton').show();
			$('#insertLabel').show();
			$('#label').val("");
			$('#description').val("");
			$('#ansa').val("");
			$('#ansb').val("");
			$('#ansc').val("");
			$('#ansd').val("");
			$('#anse').val("");
			$('#ansf').val("");
			$('#ansg').val("");
			$('#ansh').val("");
			$('#fullAnswer').val("");
			$('#cansa1').prop('checked', false);
			$('#cansa2').prop('checked', false);
			$('#cansb1').prop('checked', false);
			$('#cansb2').prop('checked', false);
			$('#cansc1').prop('checked', false);
			$('#cansc2').prop('checked', false);
			$('#cansd1').prop('checked', false);
			$('#cansd2').prop('checked', false);
			$('#canse1').prop('checked', false);
			$('#canse2').prop('checked', false);
			$('#cansf1').prop('checked', false);
			$('#cansf2').prop('checked', false);
			$('#cansg1').prop('checked', false);
			$('#cansg2').prop('checked', false);
			$('#cansh1').prop('checked', false);
			$('#cansh2').prop('checked', false);

			$('#detailModal').show();
		}
		
		function insert() {
			console.log("Chiamato insert");
			var ca;
			var cb;
			var cc;
			var cd;
			var ce;
			var cf;
			var cg;
			var ch;
			
//			Answer A
			var isChecked1 = $('#cansa1:checked').val() ? true : false;
			var isChecked2 = $('#cansa2:checked').val() ? true : false;

			if (isChecked1 & !isChecked2){
				ca = true;
			}else{
				ca = false;
			}

//			Answer B
			var isChecked3 = $('#cansb1:checked').val() ? true : false;
			var isChecked4 = $('#cansb2:checked').val() ? true : false;

			if (isChecked3 & !isChecked4){
				cb = true;
			}else{
				cb = false;
			}

//			Answer C
			var isChecked5 = $('#cansc1:checked').val() ? true : false;
			var isChecked6 = $('#cansc2:checked').val() ? true : false;

			if (isChecked5 & !isChecked6){
				cc = true;
			}else{
				cc = false;
			}

//			Answer D
			var isChecked7 = $('#cansd1:checked').val() ? true : false;
			var isChecked8 = $('#cansd2:checked').val() ? true : false;

			if (isChecked7 & !isChecked8){
				cd = true;
			}else{
				cd = false;
			}

//			Answer E
			var isChecked9 = $('#canse1:checked').val() ? true : false;
			var isChecked10 = $('#canse2:checked').val() ? true : false;

			if (isChecked9 & !isChecked10){
				ce = true;
			}else{
				ce = false;
			}

//			Answer F
			var isChecked11 = $('#cansf1:checked').val() ? true : false;
			var isChecked12 = $('#cansf2:checked').val() ? true : false;

			if (isChecked11 & !isChecked12){
				cf = true;
			}else{
				cf = false;
			}

//			Answer G
			var isChecked13 = $('#cansg1:checked').val() ? true : false;
			var isChecked14 = $('#cansg2:checked').val() ? true : false;

			if (isChecked13 & !isChecked14){
				cg = true;
			}else{
				cg = false;
			}

//			Answer H
			var isChecked15 = $('#cansh1:checked').val() ? true : false;
			var isChecked16 = $('#cansh2:checked').val() ? true : false;

			if (isChecked15 & !isChecked16){
				ch = true;
			}else{
				ch = false;
			}
			
			var dataInsert = {
				"label":$('#label').val(),
				"description":$('#description').val(),
				"ansa":$('#ansa').val(),
				"ansb":$('#ansb').val(),
				"ansc":$('#ansc').val(),
				"ansd":$('#ansd').val(),
				"anse":$('#anse').val(),
				"ansf":$('#ansf').val(),
				"ansg":$('#ansg').val(),
				"ansh":$('#ansh').val(),
				"cansa":ca,
				"cansb":cb,
				"cansc":cc,
				"cansd":cd,
				"canse":ce,
				"cansf":cf,
				"cansg":cg,
				"cansh":ch,
				"fullAnswer":$('#fullAnswer').val()
				
			}
			
 			$.ajax({
				type: "POST",
				url: questionApi,
				data: dataInsert,
				dataType: 'json',
				//esegue l'azione (url) e assegna a returnMsg il messaggio ricevuto dalla Servlet
				success: function(returnMsg){ 
					console.log("Insert OK "+returnMsg);
					$('#detailModal').hide();
					if(returnMsg==true){
						refreshTable();
					}
				},
				error: function(){
					console.log("Insert KO "+returnMsg);
				}
			});
		
		}
		
		function validateForm(label) {
			console.log("validateForm");
			console.log(label);
			
			if (label.length < 3) {
				$('#labelError').show();
				$('#label').css('background-color', 'red');
//				document.getElementById("label").style.backgroundColor = 'red';
				return false;
			}
			
			return true;
		}