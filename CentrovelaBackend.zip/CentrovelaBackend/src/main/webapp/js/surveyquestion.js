/**
 * 
 */
		var modal = document.getElementById('detailModal');
		
		window.onclick = function(event) {
		    if (event.target == modal) {
		        modal.style.display = "none";
		    }
		}
		
		function getEntityFromServer(id){
			console.log("getSurveyQuestionFromServer: " + id);
			
			
			var xhttp = new XMLHttpRequest();
			xhttp.onreadystatechange = function(){
				if(this.readyState == 4 && this.status == 200){
					
					console.log(this.responseText);
//					currentObj = JSON.parse('{\"id\":1,\"survey_id\": 1,\"question_id\": 3,\"position\": 4};');
					currentObj = JSON.parse(this.responseText);
					if(currentObj != null){
						
//						document.getElementById("idSurveyQuestion").value = currentObj.id;	
						$('#idSurveyQuestion').val(currentObj.id);
//						document.getElementById("survey_id").value = currentObj.survey_id;
						$('#survey_id').val(currentObj.survey_id);
//						document.getElementById("question_id").value = currentObj.question_id;
						$('#question_id').val(currentObj.question_id);
//						document.getElementById("position").value = currentObj.position;		
						$('#position').val(currentObj.position);
						}
				}
			};
			xhttp.open("GET", getAction + id, true);
			xhttp.send();
			
			
			
			
		}
		function createTable(){
			console.log("invocato createTable");
			var startTable = "<table>	<tr><th>surveyquestion.table.survey_id</th><th>surveyquestion.table.question_id</th><th>surveyquestion.table.position</th><th></th><th></th</tr>";
			var bodyTable = "";
			for(var i=0; i<currentList.length; i++){
				var tmp = "<tr><td align='right' bgcolor='#ffffff'>" + currentList[i].survey_id + " </td>" + 
				"<td align='right' bgcolor='#ffffff'>" + currentList[i].question_id + "</td>" +
				"<td align='right' bgcolor='#ffffff'>" + currentList[i].position + "</td>" + 
				"<td>" +
			//	"<form id='surveyquestionFormDelete" + currentList[i].id + "' action='" + deleteAction + "' method='POST'>" +
			//	"<input type='hidden' name='id' id='idSurveyQuestionDelete' value='" + currentList[i].id + "'>" +
				"<input type='button' value='Delete' onclick='deleteById(" + currentList[i].id + ");'>" +
			//	"</form>" +
				"</td><td><input type='button' id='myBtn' value='surveyquestion.survey.question.detail.button.update' onclick='openDetailDialogUpdate(" + currentList[i].id + ");'>" + 
				"</td><tr>" ;
				bodyTable += tmp;
				
			}
			var endTable = "</table>";
			document.getElementById("tableList").innerHTML = startTable + bodyTable + endTable; 
			////////////////////////////////////////////////////////////////////////////////////////////////////////////
		}
		
		function refreshTable() {
			console.log("getAllEntities from server: ");
			var xhttp = new XMLHttpRequest();
			  xhttp.onreadystatechange = function() {
			    if (this.readyState == 4 && this.status == 200) {
			    	console.log(this.responseText);
			    	currentList=JSON.parse(this.responseText);
			    	createTable();
			    }
			  };
			  xhttp.open("GET", getListAction, true);
			  xhttp.send();
		}
				
		function closeDetailDialog() {

//			 document.getElementById('detailModal').style.display = "none"; 
				$('#detailModal').hide();
		}
		
		function openDetailDialogUpdate(id) {
			
			console.log("id: "+ id);
		
//			document.getElementById("editButton").style.display = 'block';
			$('#editButton').show();
//			document.getElementById("updateLabel").style.display = 'block';
			$('#updateLabel').show();
//			document.getElementById("insertButton").style.display = 'none';
			$('#insertButton').hide();
//			document.getElementById("insertLabel").style.display = 'none';
			$('#insertLabel').hide();
//			document.getElementById("idSurveyQuestion").value = "";	
			$('#idSurveyQuestion').val("");
//			document.getElementById("survey_id").value = "";
			$('#survey_id').val("");
//			document.getElementById("question_id").value = "";
			$('#question_id').val("");
//			document.getElementById("position").value = "";	
			$('#position').val("");
			getEntityFromServer(id);
			
			
//			document.getElementById("detailModal").style.display = 'block';	
			$('#detailModal').show();
		}
		
		function update() {
			var updateSQ = {
					"id" : $('#idSurveyQuestion').val(),
					"survey_id" : $('#survey_id').val(),
					"question_id" : $('#question_id').val(),
					"position" : $('#position').val()
			};
		
			$.ajax({
			      type: "POST",
			      url: updateAction,
			      data: updateSQ,
			      dataType: 'json',
			      success: function(returnMsg)
			     
			      {
			    	closeDetailDialog();
			        console.log("OK" + returnMsg);
			        if(returnMsg == true){
			        	refreshTable();
			        }
			      },
			      error: function()
			      {
			    	  console.log(" update KO");
			      }
			    });
			

		}
		
		
		function deleteById(id) {
			
			console.log("deleteById Id: "+id);
			var data2 = {"id" : id};
			
			$.ajax({
			      type: "POST",
			      url: deleteAction,
			      data: data2,
			      dataType: 'json',
			      success: function(returnMsg)
//			     
			      {
			    	closeDetailDialog();
			        console.log("OK" + returnMsg);
			        if(returnMsg == true){
			        	refreshTable();
			        }
			      },
			      error: function()
			      {
			    	  console.log("delete by id KO");
			      }
			});
		}
		
		function openDetailDialogInsert() {
			
//			document.getElementById("editButton").style.display = 'none';
			$('#editButton').hide();
//			document.getElementById("updateLabel").style.display = 'none';
			$('#updateLabel').hide();
//			document.getElementById("insertButton").style.display = 'block';
			$('#insertButton').show();
//			document.getElementById("insertLabel").style.display = 'block';
			$('#insertLabel').show();
//			document.getElementById("detailModal").style.display = 'block';
			$('#detailModal').show();
//			document.getElementById("survey_id").value = "";
			$('#survey_id').val("");
//			document.getElementById("question_id").value = "";
			$('#question_id').val("");
//			document.getElementById("position").value = "";
			$('#position').val("");
		}
		
		function insert() {
			validateForm($('#survey_id').val(), $('#question_id').val(),$('#position').val());
			var sq = {  
					// equivale a {"survey_id" : document.getElementById("survey_id").value};
					"survey_id" : $('#survey_id').val(),
					"question_id" : $('#question_id').val(),
					"position" : $('#position').val()
					};
			 $.ajax({
			      type: "POST",
			      url: insertAction,
			      data: sq,
			      dataType: 'json',
			      success: function(returnMsg)			     
			      {
			    	closeDetailDialog();
			        console.log("OK" + returnMsg);
			        if(returnMsg == true){
			        	refreshTable();
			        }
			      },
			      error: function()
			      {
			    	  console.log("insert KO");
			      }
			    });

		
		}
		
		function validateForm(survey_id,question_id,position) {
			console.log("validateForm");
			console.log(survey_id);
			console.log(question_id);
			console.log(position);
			
			if (position > 0) {
				if (survey_id > 0) {
//					document.getElementById("labelError").style.display = 'block';
					$('#labelError').show();
					document.getElementById("survey_id").style.backgroundColor = 'red';
				
//					$(survey_id).animate({color:'red'});
					return false;
				} 
			} else {
//				document.getElementById("levelError").style.display = 'block';
				$('#levelError').show();
				document.getElementById("position").style.backgroundColor = 'red';
				return false;
			}
			
			return true;
		}