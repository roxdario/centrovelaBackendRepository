/**
 * 
 */
		var modal = document.getElementById('detailModal');
		

		window.onclick = function(event) {
		    if (event.target == modal) {
		        modal.style.display = "none";
		    }
		}
		
		function closeDetailDialog() {

			 document.getElementById('detailModal').style.display = "none"; 
		}
		
		function getUserSurveyTokenFromServer(id){
			console.log("getUserSurveyTokenFromServer "+id);
			
			
				  var xhttp = new XMLHttpRequest();
				  xhttp.onreadystatechange = function() {
				    if (this.readyState == 4 && this.status ==   200) {
				     console.log(this.responseText);
//				     currentObj = JSON.parse('{"id": 1, "userid":1,"surveyid":1, "generatedtoken":"stringa", "expirationdate":"2015-05-24"}');
				     currentObj = JSON.parse(this.responseText);

				    }
				  };
				  xhttp.open("GET", getAction, true);
				  xhttp.send();
				
		}
//		
		function openDetailDialogUpdate(id) {
			
			console.log("stampa dell'id: "+id);
		
			document.getElementById("editButton").style.display = 'block';
			document.getElementById("updateLabel").style.display = 'block';
			document.getElementById("insertButton").style.display = 'none';
			document.getElementById("insertLabel").style.display = 'none';
			
			currentObj = null;
			getUserSurveyTokenFromServer(id);
			
			if (currentObj != null){
			
			document.getElementById("userid").value = currentObj.userid;
			document.getElementById("surveyid").value = currentObj.surveyid;
			document.getElementById("generatedtoken").value = currentObj.generatedtoken;
			document.getElementById("expirationdate").value = currentObj.expirationdate;
			
			document.getElementById("idUserSurveyToken").value = currentObj.id;		
			}
			
			document.getElementById("detailModal").style.display = 'block';
		}
		
		function update() {
			
			var id = document.getElementById("idRole").value;
			var label = document.getElementById("label").value;
			var desc = document.getElementById("description").value;
			var level = document.getElementById("level").value;
			
			console.log("id: "+id+" label: "+label+" desc: "+desc+" level: "+level);
			
			document.getElementById("roleForm").action = updateAction;
			document.getElementById("roleForm").submit();
		}
		
		
		function deleteById(id) {
	
			console.log("deleteById Id: "+id);
			
			document.getElementById("idUserSurveyTokenDelete").value = id;
			var id1 = document.getElementById("idUserSurveyTokenDelete").value;
			
			document.getElementById("usersurveytokenFormDelete" + id).submit();
		}
		
		function openDetailDialogInsert() {
			
			document.getElementById("editButton").style.display = 'none';
			document.getElementById("updateLabel").style.display = 'none';
			document.getElementById("insertButton").style.display = 'block';
			document.getElementById("insertLabel").style.display = 'block';
			document.getElementById("detailModal").style.display = 'block';
			document.getElementById("userid").value = "";
			document.getElementById("surveyid").value = "";
			document.getElementById("generatedtoken").value = "";
			document.getElementById("expirationdate").value = "";
		}
		
		function insert() {
			
			var userid = document.getElementById("userid").value;
			var surveyid = document.getElementById("surveyid").value;
			var generatedtoken = document.getElementById("generatedtoken").value;
			var expirationdate = document.getElementById("expirationdate").value;
			
// 			if(!(validateForm(userid,surveyid,generatedtoken,expirationdate))) {
//				
// 				return
// 			}
			
			document.getElementById("usersurveytokenForm").action = insertAction;
			document.getElementById("usersurveytokenForm").submit();
		
		}
		
		function validateForm(label,description,level) {
			console.log("validateForm");
			console.log(label);
			console.log(description);
			console.log(level);
			
			if (level > 0) {
				if (label.length < 2) {
					document.getElementById("labelError").style.display = 'block';
					document.getElementById("label").style.backgroundColor = 'red';
					return false;
				} 
			} else {
				document.getElementById("levelError").style.display = 'block';
				document.getElementById("level").style.backgroundColor = 'red';
				return false;
			}
			
			return true;
		}